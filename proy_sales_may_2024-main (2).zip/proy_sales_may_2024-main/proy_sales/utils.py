from django.core.exceptions import ValidationError
from django.core.validators import RegexValidator
import re

# Validador para números de teléfono
phone_regex = RegexValidator(regex=r'^\d{9,15}$', message="El número de teléfono debe contener entre 9 y 15 dígitos.")

# Validador para cédula
def valida_cedula(value):
    cedula = str(value)
    if not cedula.isdigit():
        raise ValidationError('La cédula debe contener solo números.')

    longitud = len(cedula)
    if longitud != 10:
        raise ValidationError('La cédula debe tener 10 dígitos.')

    coeficientes = [2, 1, 2, 1, 2, 1, 2, 1, 2]
    total = 0
    for i in range(9):
        digito = int(cedula[i])
        coeficiente = coeficientes[i]
        producto = digito * coeficiente
        if producto > 9:
            producto -= 9
        total += producto

    digito_verificador = (total * 9) % 10
    if digito_verificador != int(cedula[9]):
        raise ValidationError('La cédula no es válida.')

# Validador para alfanuméricos
def valida_alfanumerico(value):
    if not value:  # Verifica que el valor no esté vacío
        raise ValidationError('Este campo es obligatorio.')
    if not value.isalnum():
        raise ValidationError('El campo debe ser alfanumérico (contener solo letras y números).')

# Validador para solo números
def valida_solo_numeros(value):
    if not value:  # Verifica que el valor no esté vacío
        raise ValidationError('Este campo es obligatorio.')
    if not value.isdigit():
        raise ValidationError('El campo debe contener solo números.')

# Validador para solo letras
def valida_solo_letras(value):
    if not value:  # Verifica que el valor no esté vacío
        raise ValidationError('Este campo es obligatorio.')
    if not value.isalpha():
        raise ValidationError('El campo debe contener solo letras.')

# Validador para números decimales
def valida_decimales(value):
    if not value:  # Verifica que el valor no esté vacío
        raise ValidationError('Este campo es obligatorio.')

    # Expresión regular para validar números decimales (positivos o negativos)
    decimal_regex = re.compile(r'^-?\d+(\.\d+)?$')

    if not decimal_regex.match(str(value)):
        raise ValidationError('El campo debe contener un número decimal válido.')